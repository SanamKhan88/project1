package com.example.bottombardemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import me.ibrahimsn.lib.SmoothBottomBar;

public class MainActivity extends AppCompatActivity {
    SmoothBottomBar bottomBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomBar=(SmoothBottomBar)findViewById(R.id.bottomBar);
        bottomBar.setOnItemReselectedListener(i -> {
            // the lamba functions
            switch (i){
                case 0:
                    Toast.makeText(getBaseContext(), "Home", Toast.LENGTH_SHORT).show();
                    break;
                case 1:
                    Toast.makeText(getBaseContext(), "Notification", Toast.LENGTH_SHORT).show();
                    break;
                case 2:
                    Toast.makeText(getBaseContext(), "Profile", Toast.LENGTH_SHORT).show();
                    break;

            }
            return;
        });
    }
}
